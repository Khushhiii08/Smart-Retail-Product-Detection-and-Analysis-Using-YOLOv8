import cv2
import numpy as np
import random
import os
from ultralytics import YOLO
from models import db, DetectedProduct

# Load YOLOv8 model (Ensure correct path)
model_path = "runs/detect/train25/weights/best.pt" 
model = YOLO(model_path)

# Define class labels from dataset.yaml
CLASS_NAMES = [
    'hand: grabbing', 'trolly', 'store basket', 
    'cleaners', 'cooking oil', 'dairy', 'butter', 'beverage', 'dal', 'dry fruit', 
    'flour', 'rawa', 'fruit', 'ghee and vanaspati', 'freshner', 'mosquito repellent', 
    'mosquito net', 'mosquito bat', 'tissue', 'paper roll', 'garbage bag', 'napkin', 
    'dish washer', 'scrubber', 'table cover', 'curtain', 'door mat', 'carpet', 
    'packed food', 'masala and spices', 'pulses', 'rice', 'salt', 'sugar', 'jaggery', 
    'pumpkin', 'tomato', 'spinach', 'potato', 'onion', 'lettuce', 'broccoli', 
    'cucumber', 'carrot', 'cabbage'
]

# Generate a random customer ID
def generate_customer_id():
    return f"CUST-{random.randint(1000, 9999)}"

# Check bounding box overlap
def is_overlapping(box1, box2):
    x1, y1, x2, y2 = box1
    a1, b1, a2, b2 = box2
    return not (x2 < a1 or a2 < x1 or y2 < b1 or b2 < y1)



# Function to process video with YOLOv8
def detect_from_video(video_path):
    print(f"Processing video: {video_path}")
    cap = cv2.VideoCapture(video_path)
    customer_id = generate_customer_id()

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        results = model(frame, conf=0.3)
        detected_objects = []

        for result in results:
            for obj in result.boxes.data.cpu().numpy():  # Convert to NumPy for compatibility
                x1, y1, x2, y2, confidence, class_id = obj
                class_name = CLASS_NAMES[int(class_id)]
                detected_objects.append((class_name, (x1, y1, x2, y2), confidence))

        # Separate hands, trolleys, and products
        hands = [obj[1] for obj in detected_objects if obj[0] == 'hand: grabbing']
        trolleys = [obj[1] for obj in detected_objects if obj[0] in ['trolly', 'store basket']]
        products = [obj for obj in detected_objects if obj[0] not in ['hand: grabbing', 'trolly', 'store basket']]

        with db.session.begin():  # Ensure safe database transactions
            for product_name, product_box, confidence in products:
                picked = any(is_overlapping(product_box, hand) for hand in hands)
                added_to_trolley = picked and any(is_overlapping(product_box, trolley) for trolley in trolleys)

                detected_product = DetectedProduct(
                    username=customer_id,
                    product_name=product_name,
                    action="added to basket" if added_to_trolley else "picked"
                )
                db.session.add(detected_product)

        # ✅ Draw Bounding Boxes on Frame
        for product_name, (x1, y1, x2, y2), confidence in detected_objects:
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
            cv2.putText(frame, f"{product_name} {confidence:.2f}", (int(x1), int(y1) - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        cv2.imshow("YOLOv8 Video Detection", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

# Function to process image with YOLOv8
def detect_from_image(image_path):
    print(f"Processing image: {image_path}")
    image = cv2.imread(image_path)
    customer_id = generate_customer_id()

    results = model(image, conf=0.3)
    detected_objects = []

    for result in results:
        for obj in result.boxes.data.cpu().numpy():  # Convert to NumPy
            x1, y1, x2, y2, confidence, class_id = obj
            class_name = CLASS_NAMES[int(class_id)]
            detected_objects.append((class_name, (x1, y1, x2, y2), confidence))

    hands = [obj[1] for obj in detected_objects if obj[0] == 'hand: grabbing']
    trolleys = [obj[1] for obj in detected_objects if obj[0] in ['trolly', 'store basket']]
    products = [obj for obj in detected_objects if obj[0] not in ['hand: grabbing', 'trolly', 'store basket']]

    with db.session.begin():
        for product_name, product_box, confidence in products:
            picked = any(is_overlapping(product_box, hand) for hand in hands)
            added_to_trolley = picked and any(is_overlapping(product_box, trolley) for trolley in trolleys)

            detected_product = DetectedProduct(
                username=customer_id,
                product_name=product_name,
                action="added to basket" if added_to_trolley else "picked"
            )
            db.session.add(detected_product)

    # Draw Bounding Boxes on Image
    for product_name, (x1, y1, x2, y2), confidence in detected_objects:
        cv2.rectangle(image, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
        cv2.putText(image, f"{product_name} {confidence:.2f}", (int(x1), int(y1) - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    output_path = image_path.replace(".", "_processed.")  # Save with a modified name
    cv2.imwrite(output_path, image)  # Save the modified image
    print(f"Processed image saved at: {output_path}")  # Debugging log