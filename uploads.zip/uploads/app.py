from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import os
from models import db, User, DetectedProduct  
from detect import detect_from_video, detect_from_image  

app = Flask(__name__, template_folder="C:\\Users\\jolly\\Desktop\\customer-tracking\\templates")  
app.secret_key = "your_secret_key"

# Database Configuration
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///customer_products.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = "uploads"

# Initialize SQLAlchemy
db.init_app(app)

# Ensure the uploads directory exists
if not os.path.exists(app.config["UPLOAD_FOLDER"]):
    os.makedirs(app.config["UPLOAD_FOLDER"])

# Create database tables inside app context
with app.app_context():
    db.create_all()

# Home route redirects to login
@app.route("/")
def index():
    if "authenticated" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

# Signup route
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        password = request.form.get("password")

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email already registered! Please log in.", "error")
            return redirect(url_for("login"))

        hashed_password = generate_password_hash(password)

        new_user = User(name=name, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        session["authenticated"] = True
        session["user_email"] = email  
        flash("Account created successfully! You are now logged in.", "success")
        return redirect(url_for("dashboard"))

    return render_template("signup.html")

# Login route
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            session["authenticated"] = True
            session["user_email"] = email  
            flash("Login successful!", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid email or password!", "error")

    return render_template("login.html")

# Logout route
@app.route("/logout")
def logout():
    session.clear()  # Clears session completely
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))

# Dashboard route
@app.route("/dashboard")
def dashboard():
    print("📌 DASHBOARD ACCESS: session =", session)  

    if "authenticated" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))

    products = DetectedProduct.query.all()
    return render_template("dashboard.html", products=products)

# Upload video route
@app.route("/upload/video", methods=["POST"])
def upload_video():
    if "authenticated" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))

    file = request.files.get("video")
    if not file:
        flash("No video file uploaded!", "error")
        return redirect(url_for("dashboard"))

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(file_path)

    detect_from_video(file_path)
    flash("Video uploaded and processed successfully!", "success")
    return redirect(url_for("dashboard"))

# Upload image route
@app.route("/upload/image", methods=["POST"])
def upload_image():
    if "authenticated" not in session:
        flash("Please log in first!", "error")
        return redirect(url_for("login"))

    file = request.files.get("image")
    if not file:
        flash("No image file uploaded!", "error")
        return redirect(url_for("dashboard"))

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(file_path)

    detect_from_image(file_path)
    flash("Image uploaded and processed successfully!", "success")
    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    app.run(debug=True)
