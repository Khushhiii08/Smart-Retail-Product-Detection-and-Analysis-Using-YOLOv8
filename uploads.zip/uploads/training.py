from ultralytics import YOLO
import torch
import sys

# Ensure CUDA is available; otherwise, exit
if not torch.cuda.is_available():
    print("❌ CUDA (GPU) is not available. Exiting...")
    sys.exit(1)

print(f"✅ Using GPU: {torch.cuda.get_device_name(0)}")

def train_yolo():
    model = YOLO("yolov8n.pt")  # Load YOLOv8 Nano Model
    print("✅ Model loaded successfully!")

    # Train model on dataset
    model.train(
        data="C:\\Users\\jolly\\OneDrive\\Desktop\\datasettt\\dataset.yaml",
        epochs=75,
        imgsz=1024,
        device=0,  # Explicitly setting GPU
        workers=0,  # Fix multiprocessing issue
        amp=False,  # Disable AMP
        conf=0.6
    )

    print(" Training complete. Model saved as best.pt")
    model.save("best.pt")
    model.export(format='onnx')

if __name__ == "__main__":
    train_yolo()